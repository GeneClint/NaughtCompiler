NaughtCompiler
==============
