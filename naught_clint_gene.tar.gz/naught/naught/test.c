#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef struct nstring_st {
  int32_t   len;
  char      str[];
} nstring_st;

int32_t test (  ) 
 { 
int32_t x;
int32_t temp0 = 2;
id y = y;
int32_t temp1 =  temp0 * y ;
int32_t temp2 =  x + temp1 ;

int32_t temp3 = 0;
return temp3;

 } 

