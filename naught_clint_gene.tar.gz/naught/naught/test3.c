#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef struct nstring_st {
  int32_t   len;
  char      str[];
} nstring_st;

int32_t main (  ) 
 { 
int32_t temp0 = strlen("a");
nstring_st* temp1 = malloc(sizeof(int32_t) + sizeof(char) * (temp0 + 1));
temp1->len = temp0;
strcpy(temp1->str, "a");
char * temp2 = temp1->str;
char * a = temp2;
int32_t temp3 = strlen("b");
nstring_st* temp4 = malloc(sizeof(int32_t) + sizeof(char) * (temp3 + 1));
temp4->len = temp3;
strcpy(temp4->str, "b");
char * temp5 = temp4->str;
int32_t temp6 = *((int32_t*)a - 1) + *((int32_t*)temp5 - 1);
nstring_st* temp7 =  malloc(sizeof(int32_t) + (temp6 + 1) * sizeof(char));
temp7->len = temp6 ;
char * temp8 = temp7->str;
strcpy (temp8, a);
strcat (temp8, temp5);
a = temp8;
char * temp9 = a;

printf("%s\n", a);
char * temp10 = a;

int32_t temp11 = 0;
return temp11;

 } 

