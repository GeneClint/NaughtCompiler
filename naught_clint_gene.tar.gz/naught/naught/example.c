#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nstring_st {
  int32_t   len;
  char      str[];
} nstring_st;

int32_t main (  ) 
 { 
int32_t temp0 = 1;
int32_t x = temp0;
int32_t temp1 = 2;
int32_t temp2 =  temp1 * x ;
int32_t temp3 = 1;
int32_t temp4 =  temp2 + temp3 ;
int32_t y = temp4;
int32_t z;
id initLabel = initLabel ();
char * label = initLabel;
int32_t * p;
int32_t temp5 =  x * y ;
int32_t temp6 =  y + temp5 ;
printf("%d", temp7);
int32_t temp7 = print fact (y,p = &globalInt);
int32_t temp8 =  temp6 + temp7 ;
z = temp8;


int32_t temp9 = strlen(" = ");
nstring_st* temp10 = malloc(sizeof(int32_t) + sizeof(char) * temp9 + 1);
temp10->len = temp9;
strcpy(temp10->str, " = ");
char * temp11 = temp10->str;
int32_t temp12 = *((int32_t*)label - 1) + *((int32_t*)temp11 - 1);
nstring_st* temp13 =  malloc(sizeof(int32_t) + (temp12 + 1) * sizeof(char));
temp13->len = temp12 ;
char * temp14 = temp13->str;
strcpy (temp14, label);
strcat (temp14, temp11);
char * temp15 =  temp14;


id printf = printf ("%s %d\n",label,z);


id printf = printf ("The label '%s' has length %d\n",label,nstrlen (label));


id printf = printf ("globalInt = %d\n",*p);


int32_t temp16 = 0;
return temp16;

 } 

