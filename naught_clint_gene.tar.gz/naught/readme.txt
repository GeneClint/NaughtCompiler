Team Members: Gene Kim, Clint Malcolm
Completed:
  Our program produces correct results for correct naught programs
  int, pointer, string, function and sfunction implementation
  nstrlen for stdlib.

Incomplete:
  We completed every feature that was required for this 
  assignment. We could always do more to add to the compiler
  such as rejecting incorrect programs and giving error 
  messages, or giving warnings on possibly bad code.

Extensions:
  Allows pointers to be a pointer to a string or to an int,
  while maintaining a sense of type.
