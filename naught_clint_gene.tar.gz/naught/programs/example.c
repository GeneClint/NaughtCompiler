#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef struct nstring_st {
  int32_t   len;
  char      str[];
} nstring_st;

int32_t nstrlen ( char * s );

int32_t fact ( int32_t x , int32_t * p );

char * initLabel (  );

int32_t globalInt;
int32_t main (  ) 
 { 
int32_t temp0 = 1;
int32_t x = temp0;
int32_t temp1 = 2;
int32_t temp2 =  temp1 * x ;
int32_t temp3 = 1;
int32_t temp4 =  temp2 + temp3 ;
int32_t y = temp4;
int32_t z;
char * temp5 = initLabel ();
char * label = temp5;
int32_t * p;
int32_t temp6 =  x * y ;
int32_t temp7 =  y + temp6 ;
int32_t * temp8 = &globalInt;
p = temp8;
int32_t * temp9 = p;
int32_t temp10 = fact (y, temp9);
printf("%d\n", temp10);
int32_t temp11 = temp10;
int32_t temp12 =  temp7 + temp11 ;
z = temp12;
int32_t temp13 = z;

int32_t temp14 = strlen(" = ");
nstring_st* temp15 = malloc(sizeof(int32_t) + sizeof(char) * (temp14 + 1));
temp15->len = temp14;
strcpy(temp15->str, " = ");
char * temp16 = temp15->str;
int32_t temp17 = *((int32_t*)label - 1) + *((int32_t*)temp16 - 1);
nstring_st* temp18 =  malloc(sizeof(int32_t) + (temp17 + 1) * sizeof(char));
temp18->len = temp17 ;
char * temp19 = temp18->str;
strcpy (temp19, label);
strcat (temp19, temp16);
label = temp19;
char * temp20 = label;

int32_t temp21 = printf ("%s %d\n",label,z);

int32_t temp22 = printf ("The label '%s' has length %d\n",label,nstrlen (label));

int32_t temp23 = printf ("globalInt = %d\n",*p);

int32_t temp24 = 0;
return temp24;

 } 

