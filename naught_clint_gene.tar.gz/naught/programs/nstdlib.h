#ifndef __NSTDLIB_H
#define __NSTDLIB_H

function nstrlen(string s);

#endif
