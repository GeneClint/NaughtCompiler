#ifndef _EXAMPLE_H
#define _EXAMPLE_H

function fact(int x, pointer p); # 'function' -> returns an int
sfunction initLabel();            # 'sfunction' -> returns a string

int globalInt;

#endif //_EXAMPLE_H
